<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-5">
        <div class="col-12">
            <div class="card ">
                <div class="card-header d-flex justify-content-start align-items-center ">
                    <h3 class="card-title">Empleados</h3>
                    <a href="<?php echo e(route('empleados.create')); ?>" class="btn btn-success ml-2"><i
                            class="far fa-plus-square mr-1"></i>Crear</a>
                </div>

                <div class="card-body ">
                    <table class="table table-bordered ">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Dni</th>
                                <th>Email</th>
                                <th>Teléfono Part</th>
                                <th style="width:50px;">Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($empleado->nombre); ?></td>
                                    <td> <?php echo e($empleado->apellido); ?></td>
                                    <td> <?php echo e($empleado->dni); ?></td>
                                    <td> <?php echo e($empleado->email); ?></td>
                                    <td> <?php echo e($empleado->telefonoParticular); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('empleados.show', $empleado)); ?>"
                                                class="btn btn-primary">Ver</a>
                                            <button type="button" class="btn btn-info dropdown-toggle dropdown-icon"
                                                data-toggle="dropdown" aria-expanded="false">
                                                <span class="sr-only">Toggle Dropdown</span>
                                            </button>
                                            <div class="dropdown-menu" role="menu" style="">
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('empleados.show', $empleado)); ?>">Ver</a>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('empleados.edit', $empleado)); ?>">Modificar</a>
                                                <a class="dropdown-item" href="<?php echo e(route('hijos.index',$empleado)); ?>">Hijos</a>
                                                <div class="dropdown-divider"></div>

                                                <form action="<?php echo e(route('empleados.destroy', $empleado)); ?>" method="POST"
                                                    class="formulario-eliminar w-100 p-2">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                    <button type="submit" class="btn btn-danger w-100">
                                                        Eliminar
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

                <div class="card-footer clearfix">
                    <?php echo e($empleados->links()); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <?php if(session('Creado')): ?>
        <script>
            Swal.fire(
                'Éxito!',
                '<?php echo e(session('Creado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('Actualizado')): ?>
        <script>
            Swal.fire(
                'Actualizado!',
                '<?php echo e(session('Actualizado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('Borrado')): ?>
        <script>
            Swal.fire(
                'Borrado!',
                '<?php echo e(session('Borrado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>


    <?php if(session('Error')): ?>
        <script>
            Swal.fire({
                title: 'Error!',
                text: '<?php echo e(session('Error')); ?>',
                icon: 'error',
                confirmButtonText: 'OK'
            })
        </script>
    <?php endif; ?>


    <script>
        $('.formulario-eliminar').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Estas seguro?',
                text: "No podras revertir esto.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Borrar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    /* Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    ) */

                    this.submit();
                }

            })

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\control-de-personal\resources\views/admin/empleados/index.blade.php ENDPATH**/ ?>